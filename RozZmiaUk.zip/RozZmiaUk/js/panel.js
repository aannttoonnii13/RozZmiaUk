$(function(){
	$('#new_tab').click(function(){
		
		chrome.tabs.executeScript({
          code: 'document.querySelector(\'[class^=gui_flex-wrapper]\').style.flexDirection = \'row-reverse\';'
        });
		
	});
});